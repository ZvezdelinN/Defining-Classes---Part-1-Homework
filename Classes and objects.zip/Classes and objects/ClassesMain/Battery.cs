﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMain
{
    public class Battery
    {
        public decimal HoursToStandBy { get; set; }
        public decimal HoursToTalk { get; set; }
        public BatteryType BatteryType { get; set; }
        private string madeIn;

        public Battery()
        {
            this.HoursToStandBy = 0;
            this.HoursToTalk = 0;
            this.MadeIn = "Bulgaria";
            this.BatteryType = BatteryType.Li_Ion;
        }


        private string MadeIn
        {
            get
            {
                return this.madeIn;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The type of the battery is not entered");
                }
                this.madeIn = value;
            }
        }
    }

    public enum BatteryType
    {
        Li_Ion, NiMH, NiCd
    }

}
