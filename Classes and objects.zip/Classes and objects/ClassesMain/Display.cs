﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMain
{
    public class Display
    {
        private string typeOfDisplay;
        public double Inches { get; set; }
        private string numberOfColors;

        public Display()
        {
            this.TypeOfDisplay = "Capacitive";
            this.Inches = 0.0;
            this.NumberOfColors = "1M";
        }

        public string NumberOfColors
        {
            get
            {
                return this.numberOfColors;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The type of the display can't be empty");
                }
                this.numberOfColors = value;
            }
        }

        public string TypeOfDisplay
        {
            get
            {
                return this.typeOfDisplay;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The type of the display can't be empty");
                }
                this.typeOfDisplay = value;
            }
        }
    }
}
