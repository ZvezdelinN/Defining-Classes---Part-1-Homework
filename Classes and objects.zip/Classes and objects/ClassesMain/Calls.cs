﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMain
{
    public class Calls
    {
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
        private string dealedPnoneNumber;
        public int Duration { get; set; }

        public Calls()
        {

        }

        public Calls(DateTime date, DateTime time, int duration, string aCall)
        {
            this.Date = date;
            this.Time = time;
            this.Duration = duration;
            this.DealedPhoneNumber = aCall;
        }

        public string DealedPhoneNumber
        {
            get
            {
                return this.dealedPnoneNumber;
            }
            set
            {
                for (int i = 0; i < value.Length; i++)
                {
                    int number = value[i] - '0';
                    if (number < 0 || number > '9')
                    {
                        throw new ArgumentException("Not a number");
                    }
                }
                this.dealedPnoneNumber = value;
            }
        }

        public override string ToString()
        {
            return string.Format("{0} , {1}, {2}, {3}", this.Date, this.Time, this.Duration, this.DealedPhoneNumber);
        }
    }
}
