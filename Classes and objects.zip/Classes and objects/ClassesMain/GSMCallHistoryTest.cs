﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMain
{
    public class GSMCallHistoryTest
    {
        public GSMCallHistoryTest()
        {

        }

        public void GSMCallHistoryTestMethod()
        {
            GSM gsm = new GSM("Zizo incorp", "Nokia", "IPhone4S", 234.99M, "Zizo", PhoneColor.ORANGE);
            // GSM gsm1 = new GSM("Zizo incorp", "Nokia", "IPhone4S", 234.99M, "Zizo", PhoneColor.ORANGE);

            DateTime date = new DateTime(2015, 03, 13, 11, 11, 00);
            DateTime time = new DateTime(2015, 03, 13, 11, 15, 45);
            TimeSpan ts = time - date;

            string aNumber = "359895479900";

            int hours = ts.Hours;
            int minutes = ts.Minutes;
            int seconds = ts.Seconds;

            int totalTimeInMinutes = hours * 60 + minutes;
            Calls aCall = new Calls();


            for (int i = 0; i < 10; i++)
            {
                aCall = new Calls(date, time, totalTimeInMinutes, aNumber + i);
                gsm.AddACallToHistory(aCall);
            }

            foreach (Calls aCallFromList in gsm._CallHistory)
            {
                Console.WriteLine("The number : {0} made a call with duration : {1} min", aCallFromList.DealedPhoneNumber, aCallFromList.Duration);
            }

            double totalCost = gsm.CalculateAPhoneCall(0.37, gsm._CallHistory);
            Console.WriteLine("The total cost of a conversation before removing is : {0:C}", totalCost);

            List<int> allDurations = new List<int>();

            for (int i = 0; i < gsm._CallHistory.Count; i++)
            {
                allDurations.Add(aCall.Duration);
            }

            int indexOfMax = allDurations.IndexOf(allDurations.Max());

            gsm.DeleteACallToHistory(indexOfMax);

            totalCost = gsm.CalculateAPhoneCall(0.37, gsm._CallHistory);
            Console.WriteLine("The total cost of a conversation after removing is : {0:C}", totalCost);
        }
    }
}
