﻿using System;
namespace ClassesMain
{
    class ClassesMain
    {
        static void Main(string[] args)
        {
            GSMCallHistoryTest test = new GSMCallHistoryTest();
            test.GSMCallHistoryTestMethod();
        }
    }
}
