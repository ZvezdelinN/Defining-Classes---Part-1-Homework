﻿namespace ClassesMain
{

    using System;
    using System.Collections.Generic;


    public class GSM
    {
        private static string Iphone4{get;set;}
        public PhoneColor PhoneColor { get; set; }
        private string model;
        public Display Display { get; set; }
        public Battery Battery { get; set; }
        private string manifactorer;
        public decimal Price { get; set; }
        private string owner;

        private List<Calls> CallHistory;

        public GSM(string manifactorer, string model, string iphone4, decimal price, string owner, PhoneColor phoneColor)
            : this(manifactorer, model)
        {
            Iphone4 = iphone4;
            this.PhoneColor = phoneColor;
            this.Price = price;
            this.Owner = owner;
            CallHistory = new List<Calls>();
        }


        public GSM(string manifactorer, string model)
        {
            this.Manifactorer = manifactorer;
            this.Model = model;
            this.Display = new Display();
            this.Battery = new Battery();
        }

        public List<Calls> _CallHistory
        {
            get
            {
                return CallHistory;
            }
            set
            {
                this.CallHistory = value;
            }
        }

        public string Owner
        {
            get
            {
                return this.owner;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The model can't be null or empty!");
                }
                this.owner = value;
            }
        }

       
        public string Manifactorer
        {
            get
            {
                return this.manifactorer;
            }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The model can't be null or empty!");
                }
                this.manifactorer = value;
            }
        }

        

        public string Model
        {
            get 
            {
                return this.model;
            }
            set
            {
                if(string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The model can't be null or empty!");
                }
                this.model = value;
            }
        }

        public void DisplayAllGSMData()
        {
            Console.WriteLine("The GSM data are : GSM model : {0}, manifacturer \"{1}\", battery : {2}, display : {3}",this.Model,this.Manifactorer,this.Battery,this.Display);
        }


        public override string ToString()
        {
            return this.Model + " " + this.Manifactorer + " " + Iphone4;
        }

        public void AddACallToHistory(Calls aCall)
        {
            _CallHistory.Add(aCall);
        }

        public void DeleteACallToHistory(int position)
        {
            _CallHistory.RemoveAt(position);
        }

        public double CalculateAPhoneCall(double priseForAMinute, List<Calls> aListOfCall)
        {
            double aPriseForACall = 0.0;
            foreach (Calls singleCall in aListOfCall)
            {
                aPriseForACall += (priseForAMinute * singleCall.Duration);
            }
            return aPriseForACall;
        }

        public void ClearHistory()
        {
            _CallHistory.Clear();
        }


    }

    public enum PhoneColor
    {
        RED, YELLOW, BLACK, WHITE, BLUE, BROWN, ORANGE, MAGENTA, CIAN
    }

}
