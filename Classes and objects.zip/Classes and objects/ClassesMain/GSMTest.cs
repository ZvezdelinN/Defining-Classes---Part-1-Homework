﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMain
{
    class GSMTest
    {
        
        List<GSM> arrayOfGSMs=new List<GSM>();


        public void DisplayAllGSMData()
        {
            for (int i = 0; i < 5; i++)
            {
                GSM gsm = new GSM("Zizo incorp " + i, "My Own model " + i );
            }
        }
    }
}
